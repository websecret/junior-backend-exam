<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use Illuminate\Support\Carbon;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        if(!\File::exists(storage_path('artisan-output'))) {
            \File::makeDirectory(storage_path('artisan-output'), 0777, true);
        }
        //$schedule->command('parse:reviews')->days([1, 4])->at('01:00')->sendOutputTo(storage_path('artisan-output/parse_reviews_' . Carbon::now()->format('d-m-Y_H-i-s') . '.log'));
        $schedule->command('orders:send-sms-pack')->dailyAt('12:00', ['--time' => '12:00'])->sendOutputTo(storage_path('artisan-output/orders_send_sms_pack_' . Carbon::now()->format('d-m-Y_H-i-s') . '.log'));
        $schedule->command('orders:send-sms-pack')->dailyAt('17:00', ['--time' => '17:00'])->sendOutputTo(storage_path('artisan-output/orders_send_sms_pack_' . Carbon::now()->format('d-m-Y_H-i-s') . '.log'));
        $schedule->command('orders:send-sms-pack')->dailyAt('21:00', ['--time' => '21:00'])->sendOutputTo(storage_path('artisan-output/orders_send_sms_pack_' . Carbon::now()->format('d-m-Y_H-i-s') . '.log'));
        $schedule->command('orders:send-sms-pack', ['--date' => Carbon::yesterday()->format('d.m.Y')])->dailyAt('09:00')->sendOutputTo(storage_path('artisan-output/orders_send_sms_pack_' . Carbon::now()->format('d-m-Y_H-i-s') . '.log'));
        /*
         * Caches
         */
        //$schedule->command('cache:filters')->hourly()->sendOutputTo(storage_path('artisan-output/cache_filters_' . Carbon::now()->format('d-m-Y_H-i-s') . '.log'));
        //$schedule->command('currencies:update')->dailyAt('02:00')->sendOutputTo(storage_path('artisan-output/currencies_update_' . Carbon::now()->format('d-m-Y_H-i-s') . '.log'));
        //$schedule->command('cache:sitemap')->dailyAt('03:00')->sendOutputTo(storage_path('artisan-output/cache_sitemap_' . Carbon::now()->format('d-m-Y_H-i-s') . '.log'));
        //$schedule->command('cache:yml')->dailyAt('03:10')->sendOutputTo(storage_path('artisan-output/cache_yml_' . Carbon::now()->format('d-m-Y_H-i-s') . '.log'));
        //$schedule->command('cache:zoomos-csv')->dailyAt('03:30')->sendOutputTo(storage_path('artisan-output/cache_zoomos_csv_' . Carbon::now()->format('d-m-Y_H-i-s') . '.log'));
        //$schedule->command('tasks:send-notifications')->hourly()->sendOutputTo(storage_path('artisan-output/tasks_send_notifications_' . Carbon::now()->format('d-m-Y_H-i-s') . '.log'));
        /*$schedule
            ->command('zoomos:products', [
                '--images',
                '--full',
                '--no-log',
            ])
            ->dailyAt('03:00')
            ->sendOutputTo(
                storage_path('artisan-output/zoomos_products_' . Carbon::now()->format('d-m-Y_H-i-s') . '.log')
            );*/
        $schedule->command('products:popularity')->dailyAt('03:00');
        $schedule->command('zoomos:update-products')->hourly()->withoutOverlapping();
        $schedule->command('zoomos:update-products', ['--force'])->cron('0 01 */2 * *')->withoutOverlapping();
        $schedule->command('report:gfk')->weeklyOn(1, '07:00');
        $schedule->command('zoomos:competitors')->dailyAt('14:00');
        $schedule->command(Commands\ProductsUpdateAvailability::class)->everyThirtyMinutes()->withoutOverlapping();
        $schedule->command(Commands\SuppliersUpdate::class)->twiceDaily(0, 12);
        $schedule->command(Commands\DeliveryCarriersUpdate::class)->twiceDaily(0, 12);
        $schedule->command(Commands\SessionsClear::class)->monthly();
        $schedule->command(Commands\DashboardCache::class)->hourly();
        $schedule->command(Commands\DelaySyncSignedAt::class)->daily();
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');
    }
}
